

<?php 
$url = 'root';
include 'inc/header.php';
?>

<!--<div class="fade-overlay"></div>-->
<div class="container-fluid" style="margin-top:102px">
	<div class="row">
		<?php include"slider1.php"; ?>
	</div>
</div>

<div id="page_startcontainer">

	<div id="page_subcontainer">   

		<div id="main" role="main">         

			<div class="Container">



				<div class="row">
					<div class="span12">
						<div id="reusable_part_area" class="row">






							<style type="text/css">

								/*HP CSS resets*/
								#page_startcontainer                                {top: 100px;}
								#starthome                                          {height: 650px;margin-left: 20px;overflow: hidden;}
								#starthome .container                               {margin: 0;}
								/*HP CSS resets*/

								a.offer-hpbtn                                       {display:inline-block;color:#fff; padding: 0; margin-top: 30px; text-transform:uppercase; -webkit-animation-delay: 2s;-moz-animation-delay: 2s;-o-animation-delay: 2s;animation-delay: 2s;font-size: 20px; line-height: 20px; background:none; -webkit-transition: all 0.2s ease-in-out;-moz-transition: all 0.2s ease-in-out;-ms-transition: all 0.2s ease-in-out;-o-transition: all 0.2s ease-in-out;transition: all 0.2s ease-in-out;}
								a.offer-hpbtn.arrow h2                              {background-image: url('http://localhost/mujahid/css/upload/homepage/nav_arrow_right@2x.png');background-repeat: no-repeat;background-position: 96% 50%;background-size: 8px 16px;padding-right: 40px;line-height: 1.2;}
								a.offer-hpbtn:hover                                 {box-shadow: none;}
								a.offer-hpbtn h2                                    {font-family: "FeijoaWebMedium", Georgia, serif; text-transform: none; font-size: 26px;padding: 0;}
								#starthome h1.headline                              {text-align: center;font-family: 'FeijoaWeb-Display', Georgia, serif;  margin-top: 100px;}
								#page_startcontainer .kuoni_diff                    {margin-top: 5px;}
								#page_startcontainer .kuoni_diff h2                 {font-size: 38px; line-height: 1.2}
								img.sale-lockup                                     {width: 400px!important; margin-left: auto; margin-right: auto;-webkit-transition: all 0.2s ease-in-out;-moz-transition: all 0.3s ease-in-out;-ms-transition: all 0.3s ease-in-out;-o-transition: all 0.3s ease-in-out;transition: all 0.3s ease-in-out;}
								#starthome h1.headline                              {margin-bottom: 0;}
								.no-touch img.sale-lockup:hover                     {-webkit-box-shadow: 0 46px 45px -29px rgba(0,0,0,0.37);box-shadow: 0 46px 45px -29px rgba(0,0,0,0.37);}

								#starthome ul#starthome_cta li a h2                 {font-size: 34px;}
								#starthome ul#starthome_cta li a p                  {font-size: 16px;font-family: "open_sanssemibold", sans-serif;}
								.showme                                             {display: none;}
								.hideme                                             {display: inline;}
								.pp                         {    font-size: 60%;
									text-transform: uppercase;}


									/* Large desktop */
									@media (min-width: 1200px) { 
										/*HP CSS resets*/
										#starthome                                          {margin-left: 30px;}
										/*HP CSS resets*/

										#starthome ul#starthome_cta                         {margin-top: 50px;}
										#starthome ul#starthome_cta li a h2                 {font-size: 30px;}
									}

									/* Portrait tablet to landscape and desktop */
									@media (min-width: 768px) and (max-width: 979px) { 
										/*HP CSS resets*/
										#page_startcontainer                                {top: 50px;}
										#starthome                                          {height: 630px;}
										/*HP CSS resets*/

										#starthome ul#starthome_cta                         {margin: 50px 0 15px 0}
										img.sale-lockup                                     {width: 320px!important;}


									}

									/* Landscape phone to portrait tablet */
									@media (max-width: 767px) { 
										/*HP CSS resets*/
										#page_startcontainer                                {top: 50px;}
										#starthome                                          {height: 460px;margin-left: 0;}
										/*HP CSS resets*/

										a.offer-hpbtn h2                                    {font-size: 18px;}
										a.offer-hpbtn                                       {margin-top: 0;}
										#starthome h1.headline                              {margin-top:45px; margin-bottom:10px;}
										img.sale-lockup                                     {max-width: 240px!important;}
										#starthome ul#starthome_cta                         {margin-top: 20px;}
										#starthome ul#starthome_cta li a h2                 {font-size: 20px;}
									}

									/* Landscape phones and down */
									@media (max-width: 480px) { 
										img.sale-lockup                                     {max-width: 200px!important;}
										#starthome ul#starthome_cta                         {margin-top: 20px;}
										#starthome h1.headline                              {margin-top:45px; margin-bottom:10px;}
										.showme                                             {display: block;}
										.hideme                                             {display: none;}
									}

								</style>


								<div class="span100  plain_raw_html_part wrapper" style=margin-top:0px;margin-bottom:0px;>
									<div class="part  plain_raw_html_part">



										<div id="reusable_part_area">



											<!--  NEW  grid banners-->


											<div class="container margin-bottom20">


												<div class="row">
													<div class="span12">
														<div class="hp-banner top" style="background-image: url(upload/campaigns/toy2017/hp-banner.jpg);">
															<a href="sale.php">
																<h2>SALE OFFERS</h2>
																<h4>Beach holidays | Tours &amp; Safaris  | Cruises</h4>
																<h3>View our great range</h3>
															</a>
														</div>
													</div>    
												</div>


                                                    <!-- <div class="row">
                                                           <div class="span4 hp-tablet">
                                                             <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/how-link.jpg);">
                                                                   <a href="/how-it-works">
                                                                       <h2>Our Incredible Service</h2>
                                                                       <h3>How it works</h3>
                                                                   </a>   
                                                             </div>
                                                         </div> 
                                                   
                                                           <div class="span4 hp-tablet">
                                                             <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/comp.jpg);">
                                                                 <a class="hp-big-link" href="/sale-competition">
                                                                   <h2>Win a &pound;3000 Holiday</h2>
                                                                   <h3>Enter here to Win</h3>
                                                                 </a>
                                                             </div>
                                                           </div>  
                                                   
                                                       <div class="span4 hp-tablet-full">
                                                   
                                                         <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/io-sale-hpbanner.jpg);">
                                                             <a href="/sale/indian-ocean">
                                                                 <h2>Indian Ocean Sale<br>Now On</h2>
                                                                 <h3>Holidays from &pound;899<span class="pp">pp</span></h3>
                                                             </a>
                                                         </div>
                                                   
                                                          <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/allinc.jpg);">
                                                             <a href="/sale/all-inclusive">
                                                                 <h2>All Inclusive Sale</h2>
                                                                 <h3>Holidays from &pound;1099pp</h3>
                                                             </a>
                                                         </div>
                                                   
                                                   
                                                         <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/video2.jpg);">
                                                             <a class="youtube fancybox.iframe" href="https://www.youtube.com/embed/KnGTwTrSiDM">
                                                                 <h2>Watch our tv ad</h2>
                                                                 <h3>View</h3>
                                                             </a>
                                                         </div>
                                                   
                                                           </div> 
                                                       </div>-->
                                                       <div class="row">
                                                       	<div class="span4 hp-tablet">
                                                       		<div class="hp-banner black" style="background-image: url(upload/campaigns/toy2017/weddings.jpg);">
                                                       			<a href="lu4.php">
                                                       				<h2>Weddings &amp; Honeymoons abroad</h2>
                                                       				<h3>See more</h3>
                                                       			</a>   
                                                       		</div>
                                                       	</div> 

                                                       	<div class="span4 hp-tablet">

                                                       		<div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/io-sale-hpbanner.jpg);">
                                                       			<a href="lu6.php">
                                                       				<h2>Indian Ocean Sale<br>Now On</h2>
                                                       				<h3>Holidays from &pound;899<span class="pp">pp</span></h3>
                                                       			</a>
                                                       		</div>
                                                            <!--
        <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/inspiration.jpg);">
            <a class="hp-big-link" href="/inspiration">
                <h2>Travel Inspiration</h2>
                <h3>Inspire me</h3>
            </a>
        </div>
    -->
</div>  

<div class="span4 hp-tablet-full">
	<div class="hp-banner black hp-johnlewis">
		<a href="sale.php">
			<h2>The Gift List</h2>
			<img src="upload/campaigns/TOY2016/img/john-lewis-logo.svg" width="238" height="auto">
			<h3>Exclusive partner</h3>
		</a>
	</div>
</div> 
</div>

</div>










<style type="text/css">

	.hp-banner                                                          {color: #fff; margin-top: 20px;height: 230px; background-size: cover;background-repeat: no-repeat;text-align: center; display: table; width: 100%; box-sizing: border-box; padding: 10px; position: relative; background-color: gray;}
	.hp-banner h2                                                       {font-size: 30px; margin-bottom: 5px; color: #fff; line-height: 1.2;text-shadow: 0px 0px 20px rgba(0, 0, 0, 0.6);}
	.hp-banner h3                                                       {font-family: "open_sansbold", Arial, "Helvetica Neue", Helvetica, sans-serif;  text-transform: uppercase; font-size: 18px; color: #fff;line-height: 1.2;text-shadow: 0px 0px 20px rgba(0, 0, 0, 0.6);}
	.hp-banner h4                                                       {font-family: "open_sansbold", Arial, "Helvetica Neue", Helvetica, sans-serif;  text-transform: uppercase; font-size: 20px; color: #fff;line-height: 1.2;text-shadow: 0px 0px 20px rgba(0, 0, 0, 0.6);}
	.hp-banner h3:after                                                 {content:''; background-image: url(http://localhost/mujahid/uploads/campaigns/TOY2016/img/nav_arrow_right@2x.png); background-repeat: no-repeat;background-size: 7px 13px; display: inline-block; width: 7px; height: 13px; background-position: center; margin-left: 5px;}
	.hp-banner.black h3:after                                           {background-image: url(http://localhost/mujahid/upload/campaigns/TOY2016/img/nav_arrow_right_black@2x.png);}
	.hp-banner.black h2,
	.hp-banner.black h3,
	.hp-banner.black h4                                                 {color: #000;}
	.hp-banner a                                                        {width: 100%;height: 100%; display: table-cell; vertical-align: middle;text-decoration: none!important;}
	.hp-banner.double                                                   {height:481px; margin-top: 20px;}
	.hp-johnlewis                                                       {background-color: #f3f1ed;background-image: -moz-linear-gradient( 90deg, rgb(214, 213, 209) 0%, rgb(243, 241, 237) 35%, rgb(243, 241, 237) 100%);background-image: -webkit-linear-gradient( 90deg, rgb(214, 213, 209) 0%, rgb(243, 241, 237) 35%, rgb(243, 241, 237) 100%);background-image: -ms-linear-gradient( 90deg, rgb(214, 213, 209) 0%, rgb(243, 241, 237) 35%, rgb(243, 241, 237) 100%);}

	.hp-johnlewis h2, .hp-johnlewis h3, .hp-johnlewis h4,
	.hp-banner.black h2, .hp-banner.black h3, .hp-banner.black h4       {text-shadow: none;}

	.ws-destinations                                                    {font-size: 11px!important; position: absolute; right: 0; bottom: 0; left: 0;}
	.hp-banner h3.ws-destinations:after                                 {background:none; margin: 0; width: 0; height: 0;}

	.margin-bottom20                                                    {margin-bottom: 20px;}

	@media (min-width: 1200px) { 
		.hp-banner                                                          {margin-top: 30px;}
		.hp-banner.double                                                   {margin-top: 30px; height: 491px;}
		.ws-destinations                                                    {font-size: 14px!important;}

	}

	@media (min-width: 768px) and (max-width: 979px) { 
		.hp-banner h2                                                       {font-size:28px;}
		.span4.hp-tablet                                                    {width: 352px}
		.span4.hp-tablet-full                                               {width: 724px}
		.hp-banner.double                                                   {height: 230px;}
		.ws-destinations                                                    {font-size: 14px!important;}
	}

	@media (max-width: 767px) { 
		.hp-banner h2                                                       {font-size: 26px;}
		.hp-banner h3                                                       {font-size: 16px;}
		.hp-banner.double                                                   {height: 230px;}
		.ws-destinations                                                    {font-size: 14px!important;}
	}

	@media (max-width: 480px){
		.hp-banner h2                                                       {font-size: 26px;}
		.hp-banner h3                                                       {font-size: 14px;}  
	}

</style>








</div>

<div class="clear"></div>
</div>
</div>


<div class="span12  rich_text_part wrapper" style=margin-top:0px;margin-bottom:0px;>
	<div class="part  rich_text_part">


		<div class="kuoni_diff">
			<div class="container">
				<div class="row">
					<div class="span12">
						<h2>The Kuoni Difference</h2>
						<p class="nomargin">We believe no two holidays should be the same and a human touch can make all the difference.</p>
						<p class="nomargin">We take the time to get to know you so we can help you plan an unforgettable holiday.</p>
						<a class="kuoni_btn" href="/why-kuoni">See the Kuoni difference</a></div>
					</div>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>


	<div class="span12 container_part wrapper" style=margin-top:0px;margin-bottom:0px;padding-top:0px;padding-bottom:0px;>
		<div class="part container_part">




			<div class="row">


				<div class="map hidden-phone">		
					<div class="world">
						<h2>Top Destinations</h2>
						<div class="tooltip dest1" onclick="location.href = '/north-and-central-america/north-america'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">USA &amp; CANADA</span>
						</div>

						<div class="tooltip dest2" onclick="location.href = '/caribbean-and-mexico'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Caribbean</span>
						</div>

						<div class="tooltip dest3" onclick="location.href = '/south-america'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">South America</span>
						</div>

						<div class="tooltip dest4" onclick="location.href = '/europe'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Europe</span>
						</div>

						<div class="tooltip dest5" onclick="location.href = '/africa'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Africa</span>
						</div>

						<div class="tooltip dest6" onclick="location.href = '/dubai'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Dubai</span>
						</div>

						<div class="tooltip dest7" onclick="location.href = '/mauritius'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Mauritius</span>
						</div>

						<div class="tooltip dest8" onclick="location.href = '/asia/india-nepal-and-bhutan'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">India &amp; Nepal</span>
						</div>

						<div class="tooltip dest9" onclick="location.href = '/sri-lanka'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Sri Lanka</span>
						</div>     


						<div class="tooltip dest10" onclick="location.href = '/maldives'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Maldives</span>
						</div>


						<div class="tooltip dest11" onclick="location.href = '/asia/china-and-japan'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">China &amp; Hong Kong</span>
						</div>


						<div class="tooltip dest12" onclick="location.href = '/asia/south-east-asia'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">South East Asia</span>
						</div>


						<div class="tooltip dest13" onclick="location.href = '/thailand'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Thailand</span>
						</div>


						<div class="tooltip dest14" onclick="location.href = '/malaysia'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Malaysia</span>
						</div>

						<div class="tooltip dest15" onclick="location.href = '/australasia-and-pacific'">
							<span class="tooltip-item"></span>
							<span class="tooltip-content">Australia</span>
						</div>
					</div>    
				</div>


				<div class="hidden-phone" style="display: block;margin-left: auto;margin-right:auto;margin-top:-100px;padding-bottom: 50px; position:relative;z-index:999;"><a class="kuoni_btn" href="/destinations">See all destinations</a></div>

			</div>
			<div class="clear"></div>
		</div>
	</div>


	<div class="span12 container_part wrapper" style=margin-top:0px;margin-bottom:20px;padding-top:0px;padding-bottom:0px;>
		<div class="part container_part">




			<div class="row">


				<div class="span12">
					<h2 style="font-size: 38px;line-height: 40px; text-align:center;margin-top:30px;">Popular holiday types</h2>
					<p style="text-align:center; margin-top:20px; padding-bottom:50px;">As well as our amazing destinations we offer a great range of holiday types from all inclusive holidays,<br>weddings abroad, honeymoons, safaris, escorted tours and much more.</p>
				</div>

				<div class="span12">
					<?php include"slider.php"; ?>
				</div><!-- / span12 -->
			</div>
			<div class="clear"></div>
		</div>
	</div>


	<div class="span100  plain_raw_html_part wrapper" style=margin-top:0px;margin-bottom:0px;>
		<div class="part  plain_raw_html_part">



			<div id="reusable_part_area">

                                                <!--grid banner 
        
                                                <div class="container hp-grid-wrapper">
        
                                                    
                                                    <div class="row">
        
                                                        <div class="span12 hp-tablet">
                                                            <div class="row">
                                                                <div class="span4 hp-tablet-full">
                                                                    <div class="hp-banner" style="background-image: url('upload/homepage/banners/virgin-atlantic-2.jpg');background-color:#eaeaea;background-position: center;">
                                                                        <a style="vertical-align:top;" href="/flying/virgin-atlantic?content=homepage-spot-ads-left&amp;offer=virgin">
                                                                            <h2 style="margin-top:20px;" class="small-title">Fly with Virgin Atlantic</h2>
                                                                            <h3>Find out more</h3>
                                                                        </a>
                                                                    </div>
                                                                </div>    
        
        
                                                                <div class="span4 hp-tablet">
                                                                    <div class="hp-banner" style="background-image: url('upload/homepage/banners/anse-banner.jpg');background-color:#eaeaea;background-position: center;">
                                                                        <a style="vertical-align:top;" href="/st-lucia/hotels/anse-chastanet?content=homepage-spot-ads-middle&amp;offer=anse">
                                                                            <h2 style="margin-top:20px;" class="small-title">Romantic hideaway in Saint Lucia</h2>
                                                                            <h3>4.5* scenic retreat</h3>
                                                                        </a>
                                                                    </div>
                                                                </div>  
        
                                                                <div class="span4 hp-tablet">
                                                                    <div class="hp-banner" style="background-image: url('gallery/lux-saint-gilles-37296391-1484663903-ImageGalleryLightbox.jpg');background-color:#eaeaea;background-position: center;">
                                                                        <a style="vertical-align:top" href="/la-reunion/hotels/lux-saint-gilles?content=homepage-spot-ads-right&amp;offer=gilles">
                                                                            <h2 style="margin-top:20px;" class="small-title">Discover La Réunion</h2>
                                                                            <h3>5* island luxury</h3>
                                                                        </a>
                                                                    </div>
                                                                </div>
        
                                                            </div>
        
                                                        </div>   
                                                    </div>
        
        
                                                    <div class="row">
        
                                                        <div class="span12 hp-tablet">
                                                            <div class="row">
                                                                <div class="span4 hp-tablet-full">
                                                                    <div class="hp-banner" style="background-image: url('upload/homepage/banners/universal-resorts.jpg');background-color:#eaeaea;background-position: center;">
                                                                        <a style="vertical-align:top;" href="/universal?content=homepage-spot-ads-middle&amp;offer=universal">
                                                                            <h2 style="margin-top:20px;" class="small-title">Our most popular Maldives islands</h2>
                                                                            <h3>Find paradise</h3>
                                                                        </a>
                                                                    </div>
        
                                                                </div>    
        
        
                                                                <div class="span4 hp-tablet">
                                                                    <div class="hp-banner" style="background-image: url('gallery/paradisus-rio-de-oro-resort-and-spa-37414437-1472129464-ImageGalleryLightbox.jpg');background-color:#eaeaea;background-position: center;">
                                                                        <a style="vertical-align:top;" href="/melia?content=homepage-spot-ads-middle&amp;offer=melia">
                                                                            <h2 style="margin-top:20px;" class="small-title">Adults-only or family friendly Cuba?</h2>
                                                                            <h3>Find a hotel</h3>
                                                                        </a>
                                                                    </div>
                                                                </div>  
        
                                                                <div class="span4 hp-tablet">
                                                                    <div class="hp-banner" style="background-image: url('upload/homepage/banners/BA.jpg');background-color:#eaeaea;background-position: center;">
                                                                        <a style="vertical-align:top;" href="/british-airways-offers?content=homepage-spot-ads-right&amp;offer=ba">
                                                                            <h2 style="margin-top:20px;" class="small-title">Fly direct to the Maldives</h2>
                                                                            <h3>British Airways</h3>
                                                                        </a>
                                                                    </div>
                                                                </div> 
        
                                                            </div>
        
                                                        </div>   
                                                    </div>
        
                                                </div> 	
                                                
        
        
        
        
        
                                                grid banner end-->

                                                <style type="text/css">
                                                	@media (min-width: 940px) { 
                                                		.small-title  {
                                                			font-size: 28px!important;
                                                		}
                                                	}
                                                </style>
                                            </div>

                                            <div class="clear"></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>




                        <div class="row" style="background-color:red;">

                        </div>
                    </div>
					
					
					
					
					
					
					
					
					
					<div class="row">
                                                       <div class="span4 hp-tablet">

                                                            <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/123.jpg);">
                                                                <a href="lu2.php">
                                                                    <h2>Family-friendly resort in Punta Cana</h2>
                                                                    <h3>5* all inclusive</h3>
                                                                </a>
                                                            </div>
                                                            
                                                        </div>  

                                                        <div class="span4 hp-tablet">

                                                            <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/io-sale-hpbanner.jpg);">
                                                                <a href="lu3.php">
                                                                    <h2>Couples-only escape in St Lucia</h2>
                                                                    <h3>5* romantic retreat</h3>
                                                                </a>
                                                            </div>
                                                            
                                                        </div>  

                                                       <div class="span4 hp-tablet">

                                                            <div class="hp-banner" style="background-image: url(upload/campaigns/toy2017/io-sale-hpbanner.jpg);">
                                                                <a href="lu6.php">
                                                                    <h2>Secluded setting on a private peninsula</h2>
                                                                    <h3>4* Mauritius</h3>
                                                                </a>
                                                            </div>
                                                            
                                                        </div>  
                                                    </div>
					
					
					
					
					
					<div class="world" style="background-image: url(travel.png);">
					
					<a href="index.php"></a>
					
					</div>	
					
					
					
					
					
					

                </div>


                <?php 
                include 'inc/footer.php';
                ?>
