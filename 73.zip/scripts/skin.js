/// <reference path="../../../../Scripts/Lib/TypeScript.ts"/>
$(document).ready(function () {
    setTimeout(ts_Kuoni.KuoniSkin.Initialization.SearchIcon.Init, 1);
    setTimeout(ts_Kuoni.KuoniSkin.Initialization.PhoneIconSection.Init, 1);
});
//# sourceMappingURL=Skin.js.map
