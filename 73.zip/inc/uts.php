
<?php 
/* 

<div class="under-the-sea">
	<!--<p><span style="font-size: small;"><strong><em>We're sorry, but due to technical difficulties Offers search is currently unavailable. Please try again later.</em></strong></span></p>-->
	<div class="offer-frame-container">
		<iframe src="http://booking.kuoni.co.uk/offers/n2/toy2013-v5.html" width="100%" height="490" scrolling="no" frameborder="0"></iframe>
	</div>
</div>

 
*/ 

?>